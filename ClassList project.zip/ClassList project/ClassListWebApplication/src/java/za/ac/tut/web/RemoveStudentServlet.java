/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.StudentFacadeLocal;
import za.ac.tut.model.entities.Student;

/**
 *
 * @author THEKISO MTSHANYELO
 */
public class RemoveStudentServlet extends HttpServlet {

    @EJB
    StudentFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(true);
        Long student_num = Long.parseLong(request.getParameter("student_num"));

        Student student = createStudent(student_num);
        
        sfl.remove(student);

        request.setAttribute("student", student);

        RequestDispatcher disp = request.getRequestDispatcher("remove_student_outcome.jsp");
        disp.forward(request, response);

    }

    private Student createStudent(Long student_num) {
        
        Student student = new Student();
        
        student.setStudent_num(student_num);
        
        return student;
    }
}
