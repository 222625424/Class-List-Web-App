/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import org.jboss.classfilewriter.util.ByteArrayDataOutputStream;
import za.ac.tut.model.bl.StudentFacadeLocal;
import za.ac.tut.model.entities.Image;
import za.ac.tut.model.entities.Student;
import za.ac.tut.model.entities.Subject;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@MultipartConfig
public class AddStudentServlet extends HttpServlet {

    @EJB
    private StudentFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(true);
        Long student_num = Long.parseLong(request.getParameter("student_num"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Integer age = Integer.parseInt(request.getParameter("age"));
        String gender = request.getParameter("gender");
        String[] subjects = request.getParameterValues("subjects");
        Collection<Part> part = request.getParts();
        List<Image> images = new ArrayList<>();
        
        for(Part parts: part){
            if(parts.getContentType() != null){
            
                String image_name = parts.getSubmittedFileName();
                InputStream input = parts.getInputStream();
                byte[] image_source = createImage(input);
                
                images.add(new Image(name, image_source));
            }
            
        }
        
        Student student = createStudent(student_num, name, surname, age, gender, subjects, images);
        sfl.create(student);

        request.setAttribute("student", student);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_student_outcome.jsp");
        disp.forward(request, response);

    }

    private byte[] createImage(InputStream input) {

        ByteArrayDataOutputStream baos = new ByteArrayDataOutputStream();

        byte[] buffer = new byte[1024];
        int bufferRate;

        try {
            while ((bufferRate = input.read(buffer)) != -1) {
                baos.write(buffer, 0, bufferRate);
            }
            baos.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());;
        }

        return baos.getBytes();

    }

    private Student createStudent(Long student_num, String name, String surname, Integer age, String gender, String[] subjects, List<Image> images) {

        Student student = new Student();

        List<Subject> module = new ArrayList<>();
        if (module != null) {

            for (int x = 0; x < subjects.length; x++) {
                Subject subject = new Subject();
                subject.setSub_name(subjects[x]);
                module.add(subject);

            }
        }

        student.setName(name);
        student.setSurname(surname);
        student.setStudent_num(student_num);
        student.setAge(age);
        student.setSubject(module);
        student.setGender(gender);
        student.setImages(images);

        return student;
    }

}
