/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@Entity
public class Student implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long student_num;
    private String name;
    private String surname;
    private Integer age;
    private String gender;
    @OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.EAGER)
    private List<Subject> subject;
    @OneToMany(cascade = CascadeType.ALL)
    private List<Image> images;

    public Student() {
    }

    public Student(Long student_num, String name, String surname, Integer age, String gender, List<Subject> subject, List<Image> images) {
        this.student_num = student_num;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
        this.subject = subject;
        this.images = images;
    }

    public Long getStudent_num() {
        return student_num;
    }

    public void setStudent_num(Long student_num) {
        this.student_num = student_num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<Subject> getSubject() {
        return subject;
    }

    public void setSubject(List<Subject> subject) {
        this.subject = subject;
    }

    public List<Image> getImages() {
        return images;
    }

    public void setImages(List<Image> images) {
        this.images = images;
    }
    

    public Long getId() {
        return student_num;
    }

    public void setId(Long student_num) {
        this.student_num = student_num;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (student_num != null ? student_num.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Student)) {
            return false;
        }
        Student other = (Student) object;
        if ((this.student_num == null && other.student_num != null) || (this.student_num != null && !this.student_num.equals(other.student_num))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "za.ac.tut.model.entities.Student[ id=" + student_num + " ]";
    }
    
}
