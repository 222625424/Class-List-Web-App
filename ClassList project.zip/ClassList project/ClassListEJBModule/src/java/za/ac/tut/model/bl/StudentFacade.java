/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.entities.Student;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@Stateless
public class StudentFacade extends AbstractFacade<Student> implements StudentFacadeLocal {

    @PersistenceContext(unitName = "ClassListEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFacade() {
        super(Student.class);
    }

    @Override
    public Double avgFemaleAge() {
        Query query = em.createQuery("SELECT AVG(s.age) FROM Student s WHERE s.gender like('Female')");
        Double avgFemaleAge = (Double) query.getSingleResult();

        return avgFemaleAge;
    }

    @Override
    public Double avgMaleAge() {

        Query query = em.createQuery("SELECT AVG(s.age) FROM Student s WHERE s.gender like('Male')");
        Double avgMaleAge = (Double) query.getSingleResult();

        return avgMaleAge;
    }

    @Override
    public Student youngStudent() {
        Query query = em.createQuery("SELECT s FROM Student s ORDER By s.age ASC");
        query.setMaxResults(1);
        
        Student student = (Student) query.getSingleResult();
        return student;
    }

    @Override
    public Long totalMale() {
        Query query = em.createQuery("SELECT COUNT(s) FROM Student s WHERE s.gender like('Male')");
        Long totalMale = (Long) query.getSingleResult();

        return totalMale;
    }

    @Override
    public Long totalFemale() {
        Query query = em.createQuery("SELECT COUNT(s) FROM Student s WHERE s.gender like('Female')");
        Long totalFemale = (Long) query.getSingleResult();

        return totalFemale;
    }

    @Override
    public Double femalePerc(Double totalMale, Double totalFemale) {

        totalMale = totalMale().doubleValue();
        totalFemale = totalFemale().doubleValue();

        Double femalePerc = (Double) (totalMale / (totalMale + totalFemale)) * 100;

        return femalePerc;
    }

    @Override
    public Double malePerc(Double totalMale, Double totalFemale) {

        totalMale = totalMale().doubleValue();
        totalFemale = totalFemale().doubleValue();

        Double malePerc = (totalMale / (totalMale + totalFemale)) * 100;

        return malePerc;
    }

}
