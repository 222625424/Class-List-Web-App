/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.model.entities.Student;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@Local
public interface StudentFacadeLocal {

    void create(Student student);

    void edit(Student student);

    void remove(Student student);

    Student find(Object id);
    
    Double avgFemaleAge();
    
    Double avgMaleAge();
    
    Student youngStudent();
    
    Double femalePerc(Double totalMale,Double totalFemale);
    
    Double malePerc(Double totalMale,Double totalFemale);
    
    Long totalMale();
    
    Long totalFemale();

    List<Student> findAll();

    List<Student> findRange(int[] range);

    int count();
    
}
